package com.changyu.foryou.tools;

public  class Constants {
	final static public String STATUS = "status";
	final static public String SUCCESS = "success";
	final static public String FAILURE = "failure";
	public static final String MESSAGE = "message";
	public static final String localIp = "http://www.enjoyfu.com.cn:7777/ForyouImage";
	//public static final String localIp = "http://120.26.76.252:8080/ForyouImage";
	//public static final String localIp = "http://192.168.21.104:8080/ForyouImage";
    public static String appId="app_La1y14yrPa10SeHS";
    public static String apiKey="sk_live_vBNcIdIOKPBJEU9YOq3C02PU";
	
}
