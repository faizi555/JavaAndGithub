package com.changyu.foryou.serviceImpl;

import org.springframework.stereotype.Service;

import com.changyu.foryou.service.PayService;

@Service("payService")
public class PayServiceImpl implements PayService {

}
