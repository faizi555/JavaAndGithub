package com.changyu.foryou.model;

public class VeryShortFood {
	private Long foodId;
	
	private String homeImgUrl;

	public Long getFoodId() {
		return foodId;
	}

	public void setFoodId(Long foodId) {
		this.foodId = foodId;
	}

	public String getHomeImage() {
		return homeImgUrl;
	}

	public void setHomeImage(String homeImage) {
		this.homeImgUrl = homeImage;
	}



}
