package com.changyu.foryou.service;

import java.util.Map;

public interface KeyService {

	String SelectKey(Map<String, Object> paramMap);

}
