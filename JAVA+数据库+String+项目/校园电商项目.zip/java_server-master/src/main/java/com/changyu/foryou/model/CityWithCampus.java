package com.changyu.foryou.model;

import java.util.ArrayList;
import java.util.Set;

public class CityWithCampus extends City{
	private ArrayList<Campus> campuses;

	public ArrayList<Campus> getCampuses() {
		return campuses;
	}

	public void setCampuses(ArrayList<Campus> campuses) {
		this.campuses = campuses;
	}
	

}
