package com.changyu.foryou.service;

public interface PayService {

}
