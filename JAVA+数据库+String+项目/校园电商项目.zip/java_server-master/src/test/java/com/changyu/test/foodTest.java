package com.changyu.test;

public class foodTest {

}
