# java_server
基于SpringMVC+spring+Mybatis的校园o2o电商项目的后台和管理平台

### 主要功能
1. jpush推送
2. mob短信
3. ping++支付
4. 接口签名
5. web端数据管理
6. 权限管理
7. 多校区管理

### 运行
clone下来的代码请在eclipse下运行，需要tomcat，mysql支持。

1. 将foryou.sql导入你自己的数据库中
2. 修改数据库连接配置
3. tomcat运行即可
