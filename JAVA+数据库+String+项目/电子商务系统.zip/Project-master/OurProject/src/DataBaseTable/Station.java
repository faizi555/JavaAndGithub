package DataBaseTable;

public class Station {
	private int station_id;
	private String station_number;
	private String station_name;
	private String station_province;
	private String station_city;
	private String station_country;
	private String station_street;
	private String station_address;
	private int station_leaderid;
	public int getStation_id() {
		return station_id;
	}
	public void setStation_id(int station_id) {
		this.station_id = station_id;
	}
	public String getStation_number() {
		return station_number;
	}
	public void setStation_number(String station_number) {
		this.station_number = station_number;
	}
	public String getStation_name() {
		return station_name;
	}
	public void setStation_name(String station_name) {
		this.station_name = station_name;
	}
	public String getStation_province() {
		return station_province;
	}
	public void setStation_province(String station_province) {
		this.station_province = station_province;
	}
	public String getStation_city() {
		return station_city;
	}
	public void setStation_city(String station_city) {
		this.station_city = station_city;
	}
	public String getStation_country() {
		return station_country;
	}
	public void setStation_country(String station_country) {
		this.station_country = station_country;
	}
	public String getStation_street() {
		return station_street;
	}
	public void setStation_street(String station_street) {
		this.station_street = station_street;
	}
	public String getStation_address() {
		return station_address;
	}
	public void setStation_address(String station_address) {
		this.station_address = station_address;
	}
	public int getStation_leaderid() {
		return station_leaderid;
	}
	public void setStation_leaderid(int station_leaderid) {
		this.station_leaderid = station_leaderid;
	}
	
	
	
}
