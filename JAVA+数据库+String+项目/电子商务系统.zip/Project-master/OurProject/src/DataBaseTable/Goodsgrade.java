package DataBaseTable;

public class Goodsgrade {
	private int goodsgrade_id;
	private String goodsgrade_name;
	private int goodsgrade_category;
	
	public int getGoodsgrade_id() {
		return goodsgrade_id;
	}
	public void setGoodsgrade_id(int goodsgrade_id) {
		this.goodsgrade_id = goodsgrade_id;
	}
	public String getGoodsgrade_name() {
		return goodsgrade_name;
	}
	public void setGoodsgrade_name(String goodsgrade_name) {
		this.goodsgrade_name = goodsgrade_name;
	}
	public int getGoodsgrade_category() {
		return goodsgrade_category;
	}
	public void setGoodsgrade_category(int goodsgrade_category) {
		this.goodsgrade_category = goodsgrade_category;
	}
	
}
