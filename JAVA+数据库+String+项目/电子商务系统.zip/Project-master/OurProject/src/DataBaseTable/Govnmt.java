package DataBaseTable;

public class Govnmt {
	private int govnmt_id;
	private String govnmt_type;
	private String govnmt_number;
	private String govnmt_name;
	private String govnmt_farnumber;
	public int getGovnmt_id() {
		return govnmt_id;
	}
	public void setGovnmt_id(int govnmt_id) {
		this.govnmt_id = govnmt_id;
	}
	public String getGovnmt_name() {
		return govnmt_name;
	}
	public void setGovnmt_name(String govnmt_name) {
		this.govnmt_name = govnmt_name;
	}
	public String getGovnmt_type() {
		return govnmt_type;
	}
	public void setGovnmt_type(String govnmt_type) {
		this.govnmt_type = govnmt_type;
	}
	public String getGovnmt_number() {
		return govnmt_number;
	}
	public void setGovnmt_number(String govnmt_number) {
		this.govnmt_number = govnmt_number;
	}
	public String getGovnmt_farnumber() {
		return govnmt_farnumber;
	}
	public void setGovnmt_farnumber(String govnmt_farnumber) {
		this.govnmt_farnumber = govnmt_farnumber;
	}
}
