package DataBaseTable;

import java.sql.Timestamp;

public class Ourneed {
   private int ourneed_id;
   private int ourneed_categoryid;
   private Timestamp ourneed_publishtime;
   private Timestamp ourneed_begintime;
   private Timestamp ourneed_endtime;
   private int ourneed_number;
   private double ourneed_highprice;
   private double ourneed_lowprice;
   private String  ourneed_unit;
   private String ourneed_tel;
   private String ourneed_detail;
public int getOurneed_id() {
	return ourneed_id;
}
public void setOurneed_id(int ourneed_id) {
	this.ourneed_id = ourneed_id;
}
public int getOurneed_categoryid() {
	return ourneed_categoryid;
}
public void setOurneed_categoryid(int ourneed_categoryid) {
	this.ourneed_categoryid = ourneed_categoryid;
}
public Timestamp getOurneed_publishtime() {
	return ourneed_publishtime;
}
public void setOurneed_publishtime(Timestamp ourneed_publishtime) {
	this.ourneed_publishtime = ourneed_publishtime;
}
public Timestamp getOurneed_begintime() {
	return ourneed_begintime;
}
public void setOurneed_begintime(Timestamp ourneed_begintime) {
	this.ourneed_begintime = ourneed_begintime;
}
public Timestamp getOurneed_endtime() {
	return ourneed_endtime;
}
public void setOurneed_endtime(Timestamp ourneed_endtime) {
	this.ourneed_endtime = ourneed_endtime;
}
public int getOurneed_number() {
	return ourneed_number;
}
public void setOurneed_number(int ourneed_number) {
	this.ourneed_number = ourneed_number;
}
public double getOurneed_highprice() {
	return ourneed_highprice;
}
public void setOurneed_highprice(double ourneed_highprice) {
	this.ourneed_highprice = ourneed_highprice;
}
public double getOurneed_lowprice() {
	return ourneed_lowprice;
}
public void setOurneed_lowprice(double ourneed_lowprice) {
	this.ourneed_lowprice = ourneed_lowprice;
}
public String getOurneed_unit() {
	return ourneed_unit;
}
public void setOurneed_unit(String ourneed_unit) {
	this.ourneed_unit = ourneed_unit;
}
public String getOurneed_tel() {
	return ourneed_tel;
}
public void setOurneed_tel(String ourneed_tel) {
	this.ourneed_tel = ourneed_tel;
}
public String getOurneed_detail() {
	return ourneed_detail;
}
public void setOurneed_detail(String ourneed_detail) {
	this.ourneed_detail = ourneed_detail;
}
   
   


}

