package DataBaseTable;

import java.sql.Date;


public class Staff {
	private int staff_id;
	private String staff_number;
	
	private String staff_password;
	private String staff_name;
	private String staff_idcard ;
	private Date staff_birth;
	private int staff_sex ;
	private String staff_education;
	private String staff_tel;
	private String staff_email;
	
	private int staff_department;
	private int staff_role;
	private Date staff_into;
	private String staff_remark;
	private String  staff_province;
	private String  staff_city;
	private String  staff_country;
	private String  staff_street;
	private String  staff_address;
	public int getStaff_id() {
		return staff_id;
	}
	public void setStaff_id(int staff_id) {
		this.staff_id = staff_id;
	}
	public String getStaff_number() {
		return staff_number;
	}
	public void setStaff_number(String staff_number) {
		this.staff_number = staff_number;
	}
	public String getStaff_password() {
		return staff_password;
	}
	public void setStaff_password(String staff_password) {
		this.staff_password = staff_password;
	}
	public String getStaff_name() {
		return staff_name;
	}
	public void setStaff_name(String staff_name) {
		this.staff_name = staff_name;
	}
	public String getStaff_idcard() {
		return staff_idcard;
	}
	public void setStaff_idcard(String staff_idcard) {
		this.staff_idcard = staff_idcard;
	}
	public Date getStaff_birth() {
		return staff_birth;
	}
	public void setStaff_birth(Date staff_birth) {
		this.staff_birth = staff_birth;
	}
	public int getStaff_sex() {
		return staff_sex;
	}
	public void setStaff_sex(int staff_sex) {
		this.staff_sex = staff_sex;
	}
	public String getStaff_education() {
		return staff_education;
	}
	public void setStaff_education(String staff_education) {
		this.staff_education = staff_education;
	}
	public String getStaff_tel() {
		return staff_tel;
	}
	public void setStaff_tel(String staff_tel) {
		this.staff_tel = staff_tel;
	}
	public String getStaff_email() {
		return staff_email;
	}
	public void setStaff_email(String staff_email) {
		this.staff_email = staff_email;
	}
	public int getStaff_department() {
		return staff_department;
	}
	public void setStaff_department(int staff_department) {
		this.staff_department = staff_department;
	}
	public int getStaff_role() {
		return staff_role;
	}
	public void setStaff_role(int staff_role) {
		this.staff_role = staff_role;
	}
	public Date getStaff_into() {
		return staff_into;
	}
	public void setStaff_into(Date staff_into) {
		this.staff_into = staff_into;
	}
	public String getStaff_remark() {
		return staff_remark;
	}
	public void setStaff_remark(String staff_remark) {
		this.staff_remark = staff_remark;
	}
	public String getStaff_province() {
		return staff_province;
	}
	public void setStaff_province(String staff_province) {
		this.staff_province = staff_province;
	}
	public String getStaff_city() {
		return staff_city;
	}
	public void setStaff_city(String staff_city) {
		this.staff_city = staff_city;
	}
	public String getStaff_country() {
		return staff_country;
	}
	public void setStaff_country(String staff_country) {
		this.staff_country = staff_country;
	}
	public String getStaff_street() {
		return staff_street;
	}
	public void setStaff_street(String staff_street) {
		this.staff_street = staff_street;
	}
	public String getStaff_address() {
		return staff_address;
	}
	public void setStaff_address(String staff_address) {
		this.staff_address = staff_address;
	}
		
	
	
	
	
	
	
}
