package DataBaseTable;

public class StaEvaluation {
		private int sta_evaluation_id;
		private int sta_evaluation_staid;
		private int sta_evaluation_orderid;
		private int sta_evaluation_distance;
		private int sta_evaluation_attitude;
		private int sta_evaluation_evnmt;
		public int getSta_evaluation_id() {
			return sta_evaluation_id;
		}
		public void setSta_evaluation_id(int sta_evaluation_id) {
			this.sta_evaluation_id = sta_evaluation_id;
		}
		public int getSta_evaluation_staid() {
			return sta_evaluation_staid;
		}
		public void setSta_evaluation_staid(int sta_evaluation_staid) {
			this.sta_evaluation_staid = sta_evaluation_staid;
		}
		public int getSta_evaluation_orderid() {
			return sta_evaluation_orderid;
		}
		public void setSta_evaluation_orderid(int sta_evaluation_orderid) {
			this.sta_evaluation_orderid = sta_evaluation_orderid;
		}
		public int getSta_evaluation_distance() {
			return sta_evaluation_distance;
		}
		public void setSta_evaluation_distance(int sta_evaluation_distance) {
			this.sta_evaluation_distance = sta_evaluation_distance;
		}
		public int getSta_evaluation_attitude() {
			return sta_evaluation_attitude;
		}
		public void setSta_evaluation_attitude(int sta_evaluation_attitude) {
			this.sta_evaluation_attitude = sta_evaluation_attitude;
		}
		public int getSta_evaluation_evnmt() {
			return sta_evaluation_evnmt;
		}
		public void setSta_evaluation_evnmt(int sta_evaluation_evnmt) {
			this.sta_evaluation_evnmt = sta_evaluation_evnmt;
		}
		
		
}
