package DataBaseTable;
//供应商商品
public class Suppliergoods {
		private int suppliergoods_id;
		private String suppliergoods_number;
		private int suppliergoods_supplierid;
		private int suppliergoods_categoryid;
		private double suppliergoods_lowprice;
		private double suppliergoods_highprice;
		private double suppliergoods_sum;
		private String suppliergoods_unit;
		private String suppliergoods_detail;
		public int getSuppliergoods_id() {
			return suppliergoods_id;
		}
		public void setSuppliergoods_id(int suppliergoods_id) {
			this.suppliergoods_id = suppliergoods_id;
		}
		public String getSuppliergoods_number() {
			return suppliergoods_number;
		}
		public void setSuppliergoods_number(String suppliergoods_number) {
			this.suppliergoods_number = suppliergoods_number;
		}
		public int getSuppliergoods_supplierid() {
			return suppliergoods_supplierid;
		}
		public void setSuppliergoods_supplierid(int suppliergoods_supplierid) {
			this.suppliergoods_supplierid = suppliergoods_supplierid;
		}
		public int getSuppliergoods_categoryid() {
			return suppliergoods_categoryid;
		}
		public void setSuppliergoods_categoryid(int suppliergoods_categoryid) {
			this.suppliergoods_categoryid = suppliergoods_categoryid;
		}
		public double getSuppliergoods_lowprice() {
			return suppliergoods_lowprice;
		}
		public void setSuppliergoods_lowprice(double suppliergoods_lowprice) {
			this.suppliergoods_lowprice = suppliergoods_lowprice;
		}
		public double getSuppliergoods_highprice() {
			return suppliergoods_highprice;
		}
		public void setSuppliergoods_highprice(double suppliergoods_highprice) {
			this.suppliergoods_highprice = suppliergoods_highprice;
		}
		public double getSuppliergoods_sum() {
			return suppliergoods_sum;
		}
		public void setSuppliergoods_sum(double suppliergoods_sum) {
			this.suppliergoods_sum = suppliergoods_sum;
		}
		
		public String getSuppliergoods_unit() {
			return suppliergoods_unit;
		}
		public void setSuppliergoods_unit(String suppliergoods_unit) {
			this.suppliergoods_unit = suppliergoods_unit;
		}
		public String getSuppliergoods_detail() {
			return suppliergoods_detail;
		}
		public void setSuppliergoods_detail(String suppliergoods_detail) {
			this.suppliergoods_detail = suppliergoods_detail;
		}
	
}
