package DataBaseTable;

public class Category {
	private int category_id;
	private int category_number;
	private String category_name;
	private int category_fanumber;
	private String category_displayorder;
	
	public int getCategory_id() {
		return category_id;
	}
	public void setCategory_id(int category_id) {
		this.category_id = category_id;
	}
	public int getCategory_number() {
		return category_number;
	}
	public void setCategory_number(int category_number) {
		this.category_number = category_number;
	}
	public String getCategory_name() {
		return category_name;
	}
	public void setCategory_name(String category_name) {
		this.category_name = category_name;
	}
	public int getCategory_fanumber() {
		return category_fanumber;
	}
	public void setCategory_fanumber(int category_fanumber) {
		this.category_fanumber = category_fanumber;
	}
	public String getCategory_displayorder() {
		return category_displayorder;
	}
	public void setCategory_displayorder(String category_displayorder) {
		this.category_displayorder = category_displayorder;
	}

}
