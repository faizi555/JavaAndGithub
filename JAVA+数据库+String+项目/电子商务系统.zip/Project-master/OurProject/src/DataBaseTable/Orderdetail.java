package DataBaseTable;

public class Orderdetail {
	private int detail_id;
	private int detail_orderid;
	private int detail_goodsid;
	private int detail_goodsnumber;
	private double detail_goodsprice;
	public int getDetail_id() {
		return detail_id;
	}
	public void setDetail_id(int detail_id) {
		this.detail_id = detail_id;
	}
	public int getDetail_orderid() {
		return detail_orderid;
	}
	public void setDetail_orderid(int detail_orderid) {
		this.detail_orderid = detail_orderid;
	}
	public int getDetail_goodsid() {
		return detail_goodsid;
	}
	public void setDetail_goodsid(int detail_goodsid) {
		this.detail_goodsid = detail_goodsid;
	}
	public int getDetail_goodsnumber() {
		return detail_goodsnumber;
	}
	public void setDetail_goodsnumber(int detail_goodsnumber) {
		this.detail_goodsnumber = detail_goodsnumber;
	}
	public double getDetail_goodsprice() {
		return detail_goodsprice;
	}
	public void setDetail_goodsprice(double detail_goodsprice) {
		this.detail_goodsprice = detail_goodsprice;
	}
}
