package DataBaseTable;

public class Camera {
	private int camera_id;
	private String camera_num;
	private int camera_supplierid;
	public int getCamera_id() {
		return camera_id;
	}
	public void setCamera_id(int camera_id) {
		this.camera_id = camera_id;
	}
	public String getCamera_num() {
		return camera_num;
	}
	public void setCamera_num(String camera_num) {
		this.camera_num = camera_num;
	}
	public int getCamera_supplierid() {
		return camera_supplierid;
	}
	public void setCamera_supplierid(int camera_supplierid) {
		this.camera_supplierid = camera_supplierid;
	}
}
