package DataBaseTable;
import java.sql.Timestamp;

public class Goods {
	private int goods_id;
	private int goods_category;
	private int goods_grade;
	private String goods_name;
	private Double goods_price;
	private Timestamp goods_producetime;
	private String goods_place;
	private int goods_inventory;
	private String goods_unit;
	private String goods_anothername;
	private int goods_video;
	private String goods_vantage;
	private int goods_type;
	private Timestamp goods_saletime;
	public int getGoods_id() {
		return goods_id;
	}
	public void setGoods_id(int goods_id) {
		this.goods_id = goods_id;
	}
	public int getGoods_category() {
		return goods_category;
	}
	public void setGoods_category(int goods_category) {
		this.goods_category = goods_category;
	}
	public int getGoods_grade() {
		return goods_grade;
	}
	public void setGoods_grade(int goods_grade) {
		this.goods_grade = goods_grade;
	}
	public String getGoods_name() {
		return goods_name;
	}
	public void setGoods_name(String goods_name) {
		this.goods_name = goods_name;
	}
	public Double getGoods_price() {
		return goods_price;
	}
	public void setGoods_price(Double goods_price) {
		this.goods_price = goods_price;
	}
	public Timestamp getGoods_producetime() {
		return goods_producetime;
	}
	public void setGoods_producetime(Timestamp goods_producetime) {
		this.goods_producetime = goods_producetime;
	}
	public String getGoods_place() {
		return goods_place;
	}
	public void setGoods_place(String goods_place) {
		this.goods_place = goods_place;
	}
	public int getGoods_inventory() {
		return goods_inventory;
	}
	public void setGoods_inventory(int goods_inventory) {
		this.goods_inventory = goods_inventory;
	}
	public String getGoods_unit() {
		return goods_unit;
	}
	public void setGoods_unit(String goods_unit) {
		this.goods_unit = goods_unit;
	}
	public String getGoods_anothername() {
		return goods_anothername;
	}
	public void setGoods_anothername(String goods_anothername) {
		this.goods_anothername = goods_anothername;
	}
	public int getGoods_video() {
		return goods_video;
	}
	public void setGoods_video(int goods_video) {
		this.goods_video = goods_video;
	}
	public String getGoods_vantage() {
		return goods_vantage;
	}
	public void setGoods_vantage(String goods_vantage) {
		this.goods_vantage = goods_vantage;
	}
	public int getGoods_type() {
		return goods_type;
	}
	public void setGoods_type(int goods_type) {
		this.goods_type = goods_type;
	}
	public Timestamp getGoods_saletime() {
		return goods_saletime;
	}
	public void setGoods_saletime(Timestamp goods_saletime) {
		this.goods_saletime = goods_saletime;
	}
	
}
