package DataBaseTable;

public class Point {
	private int point_id;
	private int point_orderid;
	private Double point_reduce;
	private Double point_raise;
	private int point_state;
	public int getPoint_id() {
		return point_id;
	}
	public void setPoint_id(int point_id) {
		this.point_id = point_id;
	}
	public int getPoint_orderid() {
		return point_orderid;
	}
	public void setPoint_orderid(int point_orderid) {
		this.point_orderid = point_orderid;
	}
	public Double getPoint_reduce() {
		return point_reduce;
	}
	public void setPoint_reduce(Double point_reduce) {
		this.point_reduce = point_reduce;
	}
	public Double getPoint_raise() {
		return point_raise;
	}
	public void setPoint_raise(Double point_raise) {
		this.point_raise = point_raise;
	}
	public int getPoint_state() {
		return point_state;
	}
	public void setPoint_state(int point_state) {
		this.point_state = point_state;
	}
	
}
