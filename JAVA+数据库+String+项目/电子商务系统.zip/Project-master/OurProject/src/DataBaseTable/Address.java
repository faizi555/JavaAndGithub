package DataBaseTable;

public class Address {
  private int address_id;
  private int address_userid;
  private String address_province;
  private String address_city;
  private String address_country;
  private String address_street;
  private String address_detail;
  
public int getAddress_id() {
	return address_id;
}
public void setAddress_id(int address_id) {
	this.address_id = address_id;
}

public int getAddress_userid() {
	return address_userid;
}
public void setAddress_userid(int address_userid) {
	this.address_userid = address_userid;
}
public String getAddress_province() {
	return address_province;
}
public void setAddress_province(String address_province) {
	this.address_province = address_province;
}
public String getAddress_city() {
	return address_city;
}
public void setAddress_city(String address_city) {
	this.address_city = address_city;
}
public String getAddress_country() {
	return address_country;
}
public void setAddress_country(String address_country) {
	this.address_country = address_country;
}
public String getAddress_street() {
	return address_street;
}
public void setAddress_street(String address_street) {
	this.address_street = address_street;
}
public String getAddress_detail() {
	return address_detail;
}
public void setAddress_detail(String address_detail) {
	this.address_detail = address_detail;
}
}

