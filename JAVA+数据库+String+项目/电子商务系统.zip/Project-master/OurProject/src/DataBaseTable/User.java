package DataBaseTable;

public class User {
	private int user_id;
	private String user_name;
	private String user_password;
	private int user_state;
	private String user_province;
	private String user_city;
	private String user_country;
	private String user_street;
	private String user_address;
	private String user_qq;
	private String user_weibo;
	private String user_weixin;
	private String user_zhifubao;
	private String user_idcard;
	private String user_tel;
	private String user_type;
	private double user_point;
	public int getUser_id() {
		return user_id;
	}
	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}
	public String getUser_name() {
		return user_name;
	}
	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}
	public String getUser_password() {
		return user_password;
	}
	public void setUser_password(String user_password) {
		this.user_password = user_password;
	}
	public int getUser_state() {
		return user_state;
	}
	public void setUser_state(int user_state) {
		this.user_state = user_state;
	}
	public String getUser_province() {
		return user_province;
	}
	public void setUser_province(String user_province) {
		this.user_province = user_province;
	}
	public String getUser_city() {
		return user_city;
	}
	public void setUser_city(String user_city) {
		this.user_city = user_city;
	}
	public String getUser_country() {
		return user_country;
	}
	public void setUser_country(String user_country) {
		this.user_country = user_country;
	}
	public String getUser_street() {
		return user_street;
	}
	public void setUser_street(String user_street) {
		this.user_street = user_street;
	}
	public String getUser_address() {
		return user_address;
	}
	public void setUser_address(String user_address) {
		this.user_address = user_address;
	}
	public String getUser_qq() {
		return user_qq;
	}
	public void setUser_qq(String user_qq) {
		this.user_qq = user_qq;
	}
	public String getUser_weibo() {
		return user_weibo;
	}
	public void setUser_weibo(String user_weibo) {
		this.user_weibo = user_weibo;
	}
	public String getUser_weixin() {
		return user_weixin;
	}
	public void setUser_weixin(String user_weixin) {
		this.user_weixin = user_weixin;
	}
	public String getUser_zhifubao() {
		return user_zhifubao;
	}
	public void setUser_zhifubao(String user_zhifubao) {
		this.user_zhifubao = user_zhifubao;
	}
	public String getUser_idcard() {
		return user_idcard;
	}
	public void setUser_idcard(String user_idcard) {
		this.user_idcard = user_idcard;
	}
	public String getUser_tel() {
		return user_tel;
	}
	public void setUser_tel(String user_tel) {
		this.user_tel = user_tel;
	}
	public String getUser_type() {
		return user_type;
	}
	public void setUser_type(String user_type) {
		this.user_type = user_type;
	}
	public double getUser_point() {
		return user_point;
	}
	public void setUser_point(double user_point) {
		this.user_point = user_point;
	}
	
}
