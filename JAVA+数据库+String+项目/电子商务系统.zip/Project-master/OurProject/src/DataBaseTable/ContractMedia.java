package DataBaseTable;

public class ContractMedia {
	private int contractmedia_id;
	private int contractmedia_contractid;
	private String contractmedia_title;
	private String contractmedia_url;
	public int getContractmedia_id() {
		return contractmedia_id;
	}
	public void setContractmedia_id(int contractmedia_id) {
		this.contractmedia_id = contractmedia_id;
	}
	public int getContractmedia_contractid() {
		return contractmedia_contractid;
	}
	public void setContractmedia_contractid(int contractmedia_contractid) {
		this.contractmedia_contractid = contractmedia_contractid;
	}
	public String getContractmedia_title() {
		return contractmedia_title;
	}
	public void setContractmedia_title(String contractmedia_title) {
		this.contractmedia_title = contractmedia_title;
	}
	public String getContractmedia_url() {
		return contractmedia_url;
	}
	public void setContractmedia_url(String contractmedia_url) {
		this.contractmedia_url = contractmedia_url;
	}
	
}
