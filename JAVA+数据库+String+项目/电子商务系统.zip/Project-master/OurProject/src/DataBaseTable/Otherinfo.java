package DataBaseTable;

public class Otherinfo {
	private int otherinfo_id;
	private int otherinfo_staffid;
	private String otherinfo_text;
	public int getOtherinfo_id() {
		return otherinfo_id;
	}
	public void setOtherinfo_id(int otherinfo_id) {
		this.otherinfo_id = otherinfo_id;
	}
	public int getOtherinfo_staffid() {
		return otherinfo_staffid;
	}
	public void setOtherinfo_staffid(int otherinfo_staffid) {
		this.otherinfo_staffid = otherinfo_staffid;
	}
	public String getOtherinfo_text() {
		return otherinfo_text;
	}
	public void setOtherinfo_text(String otherinfo_text) {
		this.otherinfo_text = otherinfo_text;
	}
}
