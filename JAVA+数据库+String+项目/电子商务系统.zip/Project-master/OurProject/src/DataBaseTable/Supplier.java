package DataBaseTable;


public class Supplier {
	private int supplier_id;
	private int supplier_userid;
	private String supplier_yingyezhizhao;
	private String supplier_shuiwu;
	private String supplier_jigou;
	private String supplier_liutong;
	private String supplier_anquan;
	private String supplier_renzheng;
	private String supplier_jingyingaddr;
	private String supplier_shengchanaddr;
	public int getSupplier_id() {
		return supplier_id;
	}
	public void setSupplier_id(int supplier_id) {
		this.supplier_id = supplier_id;
	}
	public int getSupplier_userid() {
		return supplier_userid;
	}
	public void setSupplier_userid(int supplier_userid) {
		this.supplier_userid = supplier_userid;
	}
	public String getSupplier_yingyezhizhao() {
		return supplier_yingyezhizhao;
	}
	public void setSupplier_yingyezhizhao(String supplier_yingyezhizhao) {
		this.supplier_yingyezhizhao = supplier_yingyezhizhao;
	}
	public String getSupplier_shuiwu() {
		return supplier_shuiwu;
	}
	public void setSupplier_shuiwu(String supplier_shuiwu) {
		this.supplier_shuiwu = supplier_shuiwu;
	}
	public String getSupplier_jigou() {
		return supplier_jigou;
	}
	public void setSupplier_jigou(String supplier_jigou) {
		this.supplier_jigou = supplier_jigou;
	}
	public String getSupplier_liutong() {
		return supplier_liutong;
	}
	public void setSupplier_liutong(String supplier_liutong) {
		this.supplier_liutong = supplier_liutong;
	}
	public String getSupplier_anquan() {
		return supplier_anquan;
	}
	public void setSupplier_anquan(String supplier_anquan) {
		this.supplier_anquan = supplier_anquan;
	}
	public String getSupplier_renzheng() {
		return supplier_renzheng;
	}
	public void setSupplier_renzheng(String supplier_renzheng) {
		this.supplier_renzheng = supplier_renzheng;
	}
	public String getSupplier_jingyingaddr() {
		return supplier_jingyingaddr;
	}
	public void setSupplier_jingyingaddr(String supplier_jingyingaddr) {
		this.supplier_jingyingaddr = supplier_jingyingaddr;
	}
	public String getSupplier_shengchanaddr() {
		return supplier_shengchanaddr;
	}
	public void setSupplier_shengchanaddr(String supplier_shengchanaddr) {
		this.supplier_shengchanaddr = supplier_shengchanaddr;
	}
	
	
	
}
