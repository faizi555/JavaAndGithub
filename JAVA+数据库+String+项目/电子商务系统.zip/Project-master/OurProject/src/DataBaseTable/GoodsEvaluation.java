package DataBaseTable;

public class GoodsEvaluation {

	private int goods_evaluation_id;
	private int goods_evaluation_goodsid;
	private int goods_evaluation_orderid;
	private int goods_evaluation_degree;
	private String goods_evaluation_detail;

	public int getGoods_evaluation_id() {
		return goods_evaluation_id;
	}
	public void setGoods_evaluation_id(int goods_evaluation_id) {
		this.goods_evaluation_id = goods_evaluation_id;
	}
	public int getGoods_evaluation_goodsid() {
		return goods_evaluation_goodsid;
	}
	public void setGoods_evaluation_goodsid(int goods_evaluation_goodsid) {
		this.goods_evaluation_goodsid = goods_evaluation_goodsid;
	}
	public int getGoods_evaluation_orderid() {
		return goods_evaluation_orderid;
	}
	public void setGoods_evaluation_orderid(int goods_evaluation_orderid) {
		this.goods_evaluation_orderid = goods_evaluation_orderid;
	}
	public int getGoods_evaluation_degree() {
		return goods_evaluation_degree;
	}
	public void setGoods_evaluation_degree(int goods_evaluation_degree) {
		this.goods_evaluation_degree = goods_evaluation_degree;
	}
	public String getGoods_evaluation_detail() {
		return goods_evaluation_detail;
	}
	public void setGoods_evaluation_detail(String goods_evaluation_detail) {
		this.goods_evaluation_detail = goods_evaluation_detail;
	}


	
}

