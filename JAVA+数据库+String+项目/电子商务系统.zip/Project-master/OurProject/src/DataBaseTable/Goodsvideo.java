package DataBaseTable;

public class Goodsvideo {
	private int goodsvideo_id;
	private int goodsvideo_goodid;
	private String goodsvideo_url;
	public int getGoodsvideo_id() {
		return goodsvideo_id;
	}
	public void setGoodsvideo_id(int goodsvideo_id) {
		this.goodsvideo_id = goodsvideo_id;
	}
	public int getGoodsvideo_goodid() {
		return goodsvideo_goodid;
	}
	public void setGoodsvideo_goodid(int goodsvideo_goodid) {
		this.goodsvideo_goodid = goodsvideo_goodid;
	}
	public String getGoodsvideo_url() {
		return goodsvideo_url;
	}
	public void setGoodsvideo_url(String goodsvideo_url) {
		this.goodsvideo_url = goodsvideo_url;
	}
}
