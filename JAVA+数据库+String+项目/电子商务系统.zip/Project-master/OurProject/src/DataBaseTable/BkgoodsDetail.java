package DataBaseTable;

public class BkgoodsDetail {
	private int bkgoodsdetail_id;
	private int bkgoodsdetail_bkgoodsid;
	private int bkgoodsdetail_num;
	private String bkgoodsdetail_unit;
	
	public int getBkgoodsdetail_id() {
		return bkgoodsdetail_id;
	}
	public void setBkgoodsdetail_id(int bkgoodsdetail_id) {
		this.bkgoodsdetail_id = bkgoodsdetail_id;
	}
	public int getBkgoodsdetail_bkgoodsid() {
		return bkgoodsdetail_bkgoodsid;
	}
	public void setBkgoodsdetail_bkgoodsid(int bkgoodsdetail_bkgoodsid) {
		this.bkgoodsdetail_bkgoodsid = bkgoodsdetail_bkgoodsid;
	}
	public int getBkgoodsdetail_num() {
		return bkgoodsdetail_num;
	}
	public void setBkgoodsdetail_num(int bkgoodsdetail_num) {
		this.bkgoodsdetail_num = bkgoodsdetail_num;
	}
	public String getBkgoodsdetail_unit() {
		return bkgoodsdetail_unit;
	}
	public void setBkgoodsdetail_unit(String bkgoodsdetail_unit) {
		this.bkgoodsdetail_unit = bkgoodsdetail_unit;
	}

}
